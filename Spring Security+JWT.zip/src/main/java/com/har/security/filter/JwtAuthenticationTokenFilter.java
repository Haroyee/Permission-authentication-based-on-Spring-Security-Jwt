package com.har.security.filter;

import com.har.model.vo.TokenInfo;
import com.har.security.SecurityUser;
import com.har.utils.JwtUtil;
import com.har.utils.RedisUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
@Component
public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {
    private HttpServletRequest request;
    private Integer userId;
    public void setRequest(HttpServletRequest httpServletRequest){
        this.request = httpServletRequest;
    }
    public HttpServletRequest getRequest(){
        return this.request;
    }
    public void setUserId(Integer userId){
        this.userId =userId;
    }
    public Integer getUserId(){
        return this.userId;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String key;
        //获取token
        setRequest(request);
        String token = request.getHeader("token");
        if (!StringUtils.hasText(token)) {
            filterChain.doFilter(request, response);
            return;
        }
        //解析token
        Claims claims;
        try {
            claims = JwtUtil.decodeToken(token);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("token非法");
        }
        //获取用户权限
        List<String> permissions = (List<String>) claims.get("permissions");
        SecurityUser securityUser = new SecurityUser();
        securityUser.setPermissions(permissions);
        //获取用户id
        Integer id = (Integer) claims.get("id");
        setUserId(id);
        //存入SecurityContextHolder
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(null,null,securityUser.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
        //放行
        filterChain.doFilter(request, response);

    }
}
