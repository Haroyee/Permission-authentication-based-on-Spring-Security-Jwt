package com.har.security;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.har.entity.User;
import com.har.mapper.UserMapper;
import com.har.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Objects;


/**
 * Security UserDetailService 实现
 */
@Service("UserDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RedisUtil redisUtil;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername,username);
        User user = userMapper.selectOne(queryWrapper);
        System.out.println(user.getUsername()+" 认证中.....");
        //不存在返回下一层处理
        if (user == null) return null;
        //存在则从数据库取出信息
        SecurityUser securityUser = new SecurityUser();
        securityUser.setUser(user);

        return new SecurityUser(securityUser.getUser(),null,null);
    }
}
