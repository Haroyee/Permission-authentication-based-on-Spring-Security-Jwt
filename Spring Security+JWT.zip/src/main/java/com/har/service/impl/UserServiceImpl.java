package com.har.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.har.entity.User;
import com.har.mapper.UserMapper;
import com.har.service.UserService;
import org.springframework.stereotype.Service;

@Service("userSerVice")
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}
