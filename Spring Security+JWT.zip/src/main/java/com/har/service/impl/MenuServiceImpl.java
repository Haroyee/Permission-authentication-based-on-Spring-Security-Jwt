package com.har.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.har.entity.Menu;
import com.har.service.MenuService;
import com.har.mapper.MenuMapper;
import org.springframework.stereotype.Service;

/**
* @author CXQ
* @description 针对表【t_menu】的数据库操作Service实现
* @createDate 2024-04-09 23:46:28
*/
@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu>
    implements MenuService{

}




