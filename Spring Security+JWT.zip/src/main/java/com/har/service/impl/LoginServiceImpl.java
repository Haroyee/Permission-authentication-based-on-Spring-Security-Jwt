package com.har.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.har.entity.Menu;
import com.har.entity.RoleMenu;
import com.har.entity.TypeRole;
import com.har.entity.User;
import com.har.mapper.*;
import com.har.model.dto.LoginInfo;
import com.har.model.dto.RegisterInfo;
import com.har.model.vo.Result;
import com.har.model.vo.TokenInfo;
import com.har.security.SecurityUser;
import com.har.security.filter.JwtAuthenticationTokenFilter;
import com.har.service.LoginService;
import com.har.utils.JwtUtil;
import com.har.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

import static com.har.enums.ResultEnum.LOGIN_SUCCESS;

@Service("loginService")
public class LoginServiceImpl implements LoginService {
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RoleMenuMapper roleMenuMapper;
    @Autowired
    private MenuMapper menuMapper;
    @Autowired
    private TypeRoleMapper typeRoleMapper;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtAuthenticationTokenFilter jwtAuthenticationTokenFilter;

    @Override
    public Result login(LoginInfo loginInfo) {
        try {
        // 用户认证
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(loginInfo.getUsername(), loginInfo.getPassword());
            Authentication authentication = authenticationManager.authenticate(authenticationToken);
        // 认证通过，生成token
            SecurityUser securityUser = (SecurityUser) authentication.getPrincipal();
            User user = securityUser.getUser();
            List<String> permissions;
            try {
                //查询权限信息
                //查询role_id
                LambdaQueryWrapper<TypeRole> typeRoleLambdaQueryWrapper = new LambdaQueryWrapper<>();
                typeRoleLambdaQueryWrapper.select(TypeRole::getRoleId).eq(TypeRole::getUserType, securityUser.getUser().getType());
                List<TypeRole> typeRoles = typeRoleMapper.selectList(typeRoleLambdaQueryWrapper);
                //查询角色菜单权限id并去重
                QueryWrapper<RoleMenu> roleMenuQueryWrapper = new QueryWrapper<>();
                //去重
                roleMenuQueryWrapper.select("DISTINCT menu_id");
                //stream流写入id
                roleMenuQueryWrapper.in("role_id",
                        typeRoles.stream()
                        .map(typeRole -> typeRole.getRoleId())
                        .collect(Collectors.toList())
                );
                List<RoleMenu> roleMenus = roleMenuMapper.selectList(roleMenuQueryWrapper);
                //查询菜单权限
                List<Menu> menus = menuMapper.selectBatchIds(roleMenus.stream().map(roleMenu -> roleMenu.getMenuId()).collect(Collectors.toList()));
                //封装权限信息
                permissions = new ArrayList<>();
                for(Menu menu:menus) if(menu.getPerms()!=null) permissions.add(menu.getPerms());
            }
            catch (NullPointerException e){
                System.out.println("出现空指针");
                permissions = null;

            }
            //将权限信息存入token
            TokenInfo tokenInfo = new TokenInfo(securityUser.getUser().getId(), securityUser.getUsername(),permissions);
            String token = JwtUtil.generateToken(tokenInfo);
            // 定义token map
            Map<String, String> res = new HashMap<>();
            res.put("token", token);
            return new Result(LOGIN_SUCCESS,res);
        } catch (AuthenticationException e) {
        // 认证未通过，返回错误信息
            return Result.fail("用户名或密码错误");
        }
    }

    @Override
    public Result loginOut() {
        System.out.println("user id is "+jwtAuthenticationTokenFilter.getUserId());

        return Result.success();
    }

    @Override
    public Result register(RegisterInfo registerInfo) {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername,registerInfo.getUsername());
        if(!Objects.isNull(userMapper.selectOne(queryWrapper))) return Result.fail("用户名已存在");
        User user = new User();
        user.setUsername(registerInfo.getUsername());
        user.setPassword(passwordEncoder.encode(registerInfo.getPassword()));
        user.setType(registerInfo.getType());
        userMapper.insert(user);
        return Result.success();
    }
}
