package com.har.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.har.model.dto.LoginInfo;
import com.har.model.dto.RegisterInfo;
import com.har.model.vo.Result;

public interface LoginService {
    Result login(LoginInfo loginInfo);

    Result loginOut();

    Result register(RegisterInfo registerInfo);
}
