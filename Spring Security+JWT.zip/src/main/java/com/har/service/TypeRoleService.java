package com.har.service;

import com.har.entity.TypeRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author CXQ
* @description 针对表【t_type_role】的数据库操作Service
* @createDate 2024-04-09 23:48:39
*/
public interface TypeRoleService extends IService<TypeRole> {

}
