package com.har.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
*
* @TableName t_role_menu
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleMenu implements Serializable {

    /**
    *
    */

    private Integer roleId;
    /**
    *
    */


    private Integer menuId;



}
