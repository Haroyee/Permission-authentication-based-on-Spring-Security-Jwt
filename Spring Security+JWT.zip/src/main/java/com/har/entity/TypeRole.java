package com.har.entity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

/**
*
* @TableName t_type_role
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeRole implements Serializable {

    /**
    *
    */

    private Integer userType;
    /**
    *
    */

    private Integer roleId;

}
