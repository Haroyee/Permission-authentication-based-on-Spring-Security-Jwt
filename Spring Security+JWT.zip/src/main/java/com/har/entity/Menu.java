package com.har.entity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

/**
*
* @TableName t_menu
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Menu implements Serializable {

    /**
    *
    */
    @TableId
    private Integer menuId;
    /**
    *
    */

    private Integer parentId;
    /**
    * 0:目录 1:菜单 2:按钮
    */

    private Integer menuType;
    /**
    *
    */

    private String path;
    /**
    * 组件路径(router)
    */

    private String componentPath;
    /**
    * 权限标识
    */

    private String perms;



}
