package com.har.mapper;

import com.har.entity.TypeRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
* @author CXQ
* @description 针对表【t_type_role】的数据库操作Mapper
* @createDate 2024-04-09 23:48:39
* @Entity com.har.entity.TypeRole
*/
@Repository
public interface TypeRoleMapper extends BaseMapper<TypeRole> {

}




