package com.har.mapper;

import com.har.entity.RoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
* @author CXQ
* @description 针对表【t_role_menu】的数据库操作Mapper
* @createDate 2024-04-09 23:48:26
* @Entity com.har.entity.RoleMenu
*/
@Repository
public interface RoleMenuMapper extends BaseMapper<RoleMenu> {

}




