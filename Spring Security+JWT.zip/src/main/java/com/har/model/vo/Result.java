package com.har.model.vo;

import com.har.enums.ResultEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.har.enums.ResultEnum.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T>{
    private Integer code;
    private String msg;
    private  T data;
    public  static <T> Result success( T data){
        return new Result(200,"OK",data);
    }
    public Result (ResultEnum e,T data){
        this.code=e.getCode();
        this.msg =e.getMsg();
        this.data=data;
    }

    public  static Result success( ){
        return new Result(SUCCESS,null);
    }
    public static <T> Result<T> error(T data){

        return new Result(ERROR,data);
    }
    public static  Result error(){

        return new Result(ERROR,null);
    }
    public static  Result fail(String msg){

        return new Result(FAIL.getCode(),msg,null);
    }
}
