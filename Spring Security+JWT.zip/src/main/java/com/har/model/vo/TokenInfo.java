package com.har.model.vo;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Token 类，设置Token里含有的信息
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel( description = "token包含信息")
public class TokenInfo {
    /**
     * 用户id
     */
    private Integer id;
    /**
     * 用户名
     */
    private String username;
    /**
     * 权限信息
     */
    private List<String> permissions;
}
