package com.har.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * 登陆需要的信息
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel( description = "登陆请求信息")
public class LoginInfo {
    /**
     * 用户名
     */
    @NotBlank(message = "不能为空")
    @Size(max = 30)
    @ApiModelProperty(value = "用户名")
    private String username;
    /**
     * 用户密码
     */
    @Size(min=6,max = 20)
    @NotEmpty(message = "不能为空")
    @ApiModelProperty(value = "密码")
    private String password;
}
