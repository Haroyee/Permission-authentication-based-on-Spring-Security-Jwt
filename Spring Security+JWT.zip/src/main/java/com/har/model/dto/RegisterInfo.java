package com.har.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterInfo {
    /**
     * 用户名
     */
    @NotBlank(message = "不能为空")
    @Size(max = 30)
    @ApiModelProperty(value = "用户名")
    private String username;
    /**
     * 用户密码
     */
    @Size(min=6,max = 20)
    @NotEmpty(message = "不能为空")
    @ApiModelProperty(value = "密码")
    private String password;
    /**
     * 用户类型
     */
    @NotEmpty(message = "不能为空")
    @ApiModelProperty(value = "类型")
    private Integer type;
}
