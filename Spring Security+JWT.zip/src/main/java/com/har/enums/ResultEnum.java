package com.har.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
public enum ResultEnum {

    SUCCESS(200,"OK"),//success
    LOGIN_SUCCESS(207,"Login successful"),//登陆成功
    VALID_ERROR(400, "valid error"),//参数错误
    UNAUTHORIZED(401, "unauthorized"),//未登录
    FAIL(402,"fail"),//fail
    ERROR(500,"error"),//error
    SYSTEM_ERROR(503,"system error"),//系统错误
    FORBIDDEN(403,"forbidden"),//禁止访问
    NOT_FOUND(404,"not found");//无请求资源
    /**
     * 状态码
     */
    private final Integer code;
    /**
     * 消息
     */
    private final String msg;
}
