package com.har.utils;

import com.har.entity.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
@Component
public class JwtUtil {
    // 这里的密钥SECRET是用于加密的密钥，应该保密且足够复杂
    private  static String SECRET;
    //token 过期时间
    private   static  long TIME_OUT;

    @Value("${custom_config.jwt.secret}")
    public void setSECRET(String secret){
        SECRET = secret;
    }
    @Value("${custom_config.jwt.timeout}")
    public void setTimeOut(long timeOut){
        TIME_OUT = timeOut;
    }
    // 生成JWT Token的方法
    public static String generateToken(Object object) {

        Map<String, Object> claims = new HashMap<>();

// 使用反射来获取对象的所有字段和相应的值
        for (java.lang.reflect.Field field : object.getClass().getDeclaredFields()) {
            field.setAccessible(true); // 允许访问私有字段
            try {
// 将字段名和字段值放入claims
                claims.put(field.getName(), field.get(object));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        return Jwts.builder()
                .setClaims(claims) // 设置声明
                .setSubject("user") // 设置主题
                .setIssuedAt(new Date(System.currentTimeMillis())) // 设置签发时间
                .setExpiration(new Date(System.currentTimeMillis() + TIME_OUT * 1000)) // 设置过期时间
                .signWith(SignatureAlgorithm.HS512, SECRET) // 设置签名使用的签名算法和密钥
                .compact(); // 构建JWT并将其压缩为一个安全的URL字符串
    }
    //设置解密Token
    public static Claims decodeToken(String token){
        return Jwts.parser()
                .setSigningKey(SECRET)
                .parseClaimsJws(token)
                .getBody();
    }
}
