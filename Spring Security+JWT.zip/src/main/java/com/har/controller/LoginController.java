package com.har.controller;

import com.har.model.dto.LoginInfo;
import com.har.model.dto.RegisterInfo;
import com.har.model.vo.Result;
import com.har.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
public class LoginController {
    @Autowired
    private LoginService loginService;

    @PostMapping("/login")
    public Result login(@Validated @RequestBody LoginInfo loginInfo){

        return loginService.login(loginInfo);
    }
    @PreAuthorize("hasAuthority('user:loginout')")
    @GetMapping("/loginout")
    public Result loginOut(){
        return loginService.loginOut();
    }
    @PostMapping("/register")
    public Result register(@RequestBody RegisterInfo registerInfo){
        return  loginService.register(registerInfo);
    }



}
