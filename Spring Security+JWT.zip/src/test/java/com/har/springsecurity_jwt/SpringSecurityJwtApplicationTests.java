package com.har.springsecurity_jwt;

import com.har.config.SecurityConfig;
import com.har.entity.User;
import com.har.model.vo.TokenInfo;
import com.har.utils.JwtUtil;
import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@SpringBootTest
class SpringSecurityJwtApplicationTests {
    @Autowired
    private PasswordEncoder passwordEncoder;


    @Test
    void contextLoads() {

    }



    }


