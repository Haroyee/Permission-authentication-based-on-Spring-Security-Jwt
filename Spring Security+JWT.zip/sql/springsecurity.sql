/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80200
 Source Host           : localhost:3306
 Source Schema         : springsafe

 Target Server Type    : MySQL
 Target Server Version : 80200
 File Encoding         : 65001

 Date: 10/04/2024 19:23:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_menu
-- ----------------------------
DROP TABLE IF EXISTS `t_menu`;
CREATE TABLE `t_menu`  (
  `menu_id` int NOT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `menu_type` tinyint NOT NULL COMMENT '0:目录 1:菜单 2:按钮',
  `path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `component_path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '组件路径(router)',
  `perms` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '权限标识',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_menu
-- ----------------------------
INSERT INTO `t_menu` VALUES (1, 1, 0, 'user', '', 'user:hello');
INSERT INTO `t_menu` VALUES (2, 1, 1, 'user', '', 'user:login');
INSERT INTO `t_menu` VALUES (3, 1, 1, 'admin', '', 'admin:success');
INSERT INTO `t_menu` VALUES (4, 1, 1, 'admin', '', 'user:loginout');

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role`  (
  `role_id` int NOT NULL COMMENT '角色id',
  `role_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色名称',
  `role_desc` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色描述',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES (1, 'super_admin', '超级管理员');
INSERT INTO `t_role` VALUES (2, 'common_admin', '普通管理员');
INSERT INTO `t_role` VALUES (3, 'common_user', '普通用户');

-- ----------------------------
-- Table structure for t_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `t_role_menu`;
CREATE TABLE `t_role_menu`  (
  `role_id` tinyint NOT NULL,
  `menu_id` int NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_role_menu
-- ----------------------------
INSERT INTO `t_role_menu` VALUES (1, 1);
INSERT INTO `t_role_menu` VALUES (1, 2);
INSERT INTO `t_role_menu` VALUES (1, 3);
INSERT INTO `t_role_menu` VALUES (1, 4);
INSERT INTO `t_role_menu` VALUES (2, 1);
INSERT INTO `t_role_menu` VALUES (2, 2);
INSERT INTO `t_role_menu` VALUES (3, 1);
INSERT INTO `t_role_menu` VALUES (3, 4);

-- ----------------------------
-- Table structure for t_type_role
-- ----------------------------
DROP TABLE IF EXISTS `t_type_role`;
CREATE TABLE `t_type_role`  (
  `user_type` tinyint NOT NULL,
  `role_id` tinyint NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_type_role
-- ----------------------------
INSERT INTO `t_type_role` VALUES (0, 1);
INSERT INTO `t_type_role` VALUES (0, 2);
INSERT INTO `t_type_role` VALUES (0, 3);
INSERT INTO `t_type_role` VALUES (1, 2);
INSERT INTO `t_type_role` VALUES (1, 3);
INSERT INTO `t_type_role` VALUES (2, 3);

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `type` tinyint NOT NULL COMMENT '0：super_admin、1:common_admin、2：common_user ',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES (1, 'har', '$2a$10$8jMaftMRsx5dhf98O6q.5O3bFb9xX7xns6EDVW2997toowCyRbNt2', 0);
INSERT INTO `t_user` VALUES (3, 'asuka', '$2a$10$Ft8BYcGjKFjMbgOxy3qWXefksFsST/y/lmGj1X.Jt2ZwjYsXvI1ay', 1);
INSERT INTO `t_user` VALUES (4, 'sora', '$2a$10$7daGMhHTDAc5HA.3CUdCSet/oAJVDq5an.pRzA9sPptyi6sgyhm/C', 2);

SET FOREIGN_KEY_CHECKS = 1;
